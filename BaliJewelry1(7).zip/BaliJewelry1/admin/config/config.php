<?php

const TITLEPAGE = 'Bali Earth Soul Jewelry';
const IMGLOGO = 'logobali.jpg';

define('SITEURL', 'https://yunitadwiliandarwati2.sites.3wa.io/BaliJewelry1/');
define('DB_HOST', 'db.3wa.io');
define('DB_NAME', 'yunitadwiliandarwati2_jewelry');
define('DB_USER', 'yunitadwiliandarwati2');
define('DB_PASS', '8e6c30d6a8b3b370505f1657304896ba');

    